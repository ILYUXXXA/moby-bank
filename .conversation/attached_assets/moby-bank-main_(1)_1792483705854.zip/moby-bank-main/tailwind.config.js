/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0D2C54', 
          light: '#1A4373',
        },
        mobyBg: {
          main: '#F4F6F9',   
          card: '#FFFFFF',   
        },
        mobyText: {
          primary: '#12161A', 
          secondary: '#6C7A89',
        }
      },
      borderRadius: {
        'main': '16px',       
      },
      boxShadow: {
        'moby': '0 4px 20px rgba(13, 44, 84, 0.08)',
        'frame': '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
      }
    },
  },
  plugins: [],
}

