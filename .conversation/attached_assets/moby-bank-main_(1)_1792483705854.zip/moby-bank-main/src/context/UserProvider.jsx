import { useState } from 'react';
import { UserContext } from './UserContext';
import { initialUserData } from '../mockData';

export const UserProvider = ({ children }) => {
  const [userData, setUserData] = useState(initialUserData);

  const toggleRole = () => {
    setUserData(prev => ({
      ...prev,
      role: prev.role === 'PARENT' ? 'CHILD' : 'PARENT'
    }));
  };

  return (
    <UserContext.Provider value={{ userData, setUserData, toggleRole }}>
      {children}
    </UserContext.Provider>
  );
};