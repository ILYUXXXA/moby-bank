import { useState } from 'react';

import { UserProvider } from './context/UserProvider';
import HomeScreen from './components/HomeScreen';
import ProductsScreen from './components/ProductsScreen';
import FamilyTab from './components/FamilyTab';
import ChatScreen from './components/ChatScreen';
import MoreScreen from './components/MoreScreen';
import TopUpScreen from './components/TopUpScreen';
import AddCardScreen from './components/AddCardScreen';
import SettingsScreen from './components/SettingsScreen';
import ApplyCardModal from './components/ApplyCardModal';
import TransferModal from './components/TransferModal';
import PayModal from './components/PayModal';
import BottomNav from './components/BottomNav';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [modalType, setModalType] = useState(null);

  const renderScreen = () => {
    switch (activeTab) {
      case 'topupPage':
        return <TopUpScreen onBack={() => setActiveTab('home')} />;
      case 'addCardPage':
        return <AddCardScreen onBack={() => setActiveTab('home')} />;
      case 'settingsPage':
        return <SettingsScreen onBack={() => setActiveTab('home')} />;
      case 'products':
        return <ProductsScreen setActiveTab={setActiveTab} />;
      case 'family':
        return <FamilyTab />;
      case 'chat':
        return <ChatScreen />;
      case 'more':
        return <MoreScreen setActiveTab={setActiveTab} />;
      case 'home':
      default:
        return <HomeScreen setActiveTab={setActiveTab} setModalType={setModalType} />;
    }
  };

  return (
    <UserProvider>
      <div className="h-[100dvh] w-full flex justify-center items-center bg-slate-400 overflow-hidden sm:p-4">
        <div className="w-full max-w-[420px] h-full sm:h-[850px] sm:max-h-[90vh] bg-slate-100 text-slate-900 flex flex-col justify-between sm:rounded-[36px] shadow-2xl overflow-hidden relative border-0 sm:border-8 border-slate-900">
          
          {/* Экран */}
          <div className="flex-1 overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
            {renderScreen()}
          </div>

          {/* Нижняя навигация */}
          <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />

          {/* Модалки */}
          <TransferModal 
            isOpen={modalType === 'transfer'} 
            onClose={() => setModalType(null)} 
          />

          <PayModal 
            isOpen={modalType === 'pay'} 
            onClose={() => setModalType(null)} 
          />

          <ApplyCardModal 
            isOpen={modalType === 'applyCard'} 
            onClose={() => setModalType(null)} 
          />
        </div>
      </div>
    </UserProvider>
  );
}